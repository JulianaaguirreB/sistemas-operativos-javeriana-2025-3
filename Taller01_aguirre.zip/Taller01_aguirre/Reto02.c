/***************************************************
 Pontificia Universidad Javeriana
 * Fecha:21 Agosto 2025
 * Autor: Juliana aguirre ballesteros
 * Materia: Sistemas Operativos
 *Temas: Memoria Dinamica
 *Reto: #02
*****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    char *q = NULL; // declaración de un puntero que inicia en  NULL

printf("Requesting space for \"Goodbye\" \n"); // muestra mensaje solicitando espacio
    
q = (char *)malloc(strlen("Goodbye") + 1); // asigna memoria dinámica para almacenar "Goodbye"

    // verifica si la asignación de memoria falló
    if (!q) {

        perror("Failed to allocate space because"); // muestra un error si no se pudo asignar memoria

        exit(1); // termina el programa si no se asigno memoria
    }

    printf("About to copy \"Goodbye\" to q at address %s \n", q); // muestra la dirección de memoria donde se almacenara "Goodbye"

    strcpy(q, "Goodbye"); // copia "Goodbye" al espacio asignado en q

    printf("String copied\n"); // mensaje indicando que se copio correctamente la cadena

    printf("%s \n", q); // muestra la cadena copiada

    return 0; // fin del programa
}
