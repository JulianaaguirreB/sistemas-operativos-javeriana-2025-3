/***************************************************
 Pontificia Universidad Javeriana
 * Fecha:21 Agosto 2025
 * Autor: Juliana aguirre ballesteros
 * Materia: Sistemas Operativos
 *Temas: Memoria Dinamica
 *Reto: #04
*****************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
int n, i, *ptr, sum = 0;

// solicita al usuario el numero de elementos

printf("Enter number of elements: ");
scanf("%d", &n);

// asigna memoria dinámicamente para 'n' enteros

ptr = (int*) calloc(n, sizeof(int));

// verifica si la memoria fue asignada correctamente

if(ptr == NULL) {

printf("Error! memory not allocated.");
exit(0);
}

// solicita al usuario que ingrese los elementos

for(i = 0; i < n; ++i) {
printf("Enter elements: ");
scanf("%d", ptr + i); //lee cada número y lo almacena en la memoria dinámica
sum += *(ptr + i); //suma el valor ingresado a la variable 'sum'
}

//muestra el resultado de la suma

printf("Sum = %d", sum);

//libera memoria que se le asigno

free(ptr);

return 0;
}
