/***************************************************
 Pontificia Universidad Javeriana
 * Fecha:21 Agosto 2025
 * Autor: Juliana aguirre ballesteros
 * Materia: Sistemas Operativos
 *Temas: Memoria Dinamica
 *Reto: #05
*****************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
int *ptr, i , n1, n2;

// solicitar al usuario el tamaño

printf("Enter size: ");
scanf("%d", &n1);

// asignar memoria dinámica para n1 elementos

ptr = (int*) malloc(n1 * sizeof(int));

//mostrar las direcciones de memoria que fueron asignadas anteriormente

printf("Addresses of previously allocated memory: ");
for(i = 0; i < n1; ++i){
printf("\n\np = %p\n", ptr+i);
}
//solicitar al usuario un nuevo tamaño

printf("\n Enter the new size: ");
scanf("%d", &n2);

//rellocating the memory 
ptr = realloc(ptr, n2 * sizeof(int));//reasignar memoria para el nuevo tamaño

printf("Addresses of newly allocated memory: ");//muestra las nuevas direcciones de memoria despues que se hace la reasignacion 

for(i = 0; i < n2; ++i){
printf("\n\np = %p\n", ptr+i);
}
//libera la memoria que se le fue asignada
free(ptr);
}
