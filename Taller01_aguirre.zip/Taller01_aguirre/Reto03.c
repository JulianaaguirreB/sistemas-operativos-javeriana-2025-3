/***************************************************
 Pontificia Universidad Javeriana
 * Fecha:21 Agosto 2025
 * Autor: Juliana aguirre ballesteros
 * Materia: Sistemas Operativos
 *Temas: Memoria Dinamica
 *Reto: #03
*****************************************************/

#include <stdio.h>  
#include <stdlib.h>  

int main() {
    int *ptr;  // declaramos un puntero de tipo  entero
    ptr = malloc(15 * sizeof(*ptr));  // asignamos memoria para 15 enteros

    if (ptr != NULL) {  // verificamos si la asignación de memoria fue correcta
        *(ptr + 5) = 480;  // asignamos el valor 480 al sexto entero 
printf("value of the 6th integer is %d\n", *(ptr + 5));
    }

    return 0;  // terminamos la ejecución del programa
}

