/******************************
 Pontificia Universidad Javeriana
 * Fecha:21 Agosto 2025
 * Autor: Juliana aguirre ballesteros
 * Materia: Sistemas Operativos
 *Temas: Memoria Dinamica
 *Reto: #01
**********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main() {
    // declaración de punteros 
    char *p;                // puntero de la cadena p
    char *q = NULL;         // puntero de la cadena q que inicia en  NULL

    // se imprime la dirección de memoria a la que apunta p

    printf("Address of p = %s\n", p);

    // Se copia la cadena a la ubicación a la que apunta p
   
 strcpy(p, "Hello, I'm the best in Operating Systems!!!");

    // Imprime la cadena copiada a p

    printf("%s\n", p);
    
    // un mensaje antes de copiar la cadena

    printf("About to copy \"Goodbye\" to q\n");
    
    // copiar la cadena "Goodbye" a q

    strcpy(q, "Goodbye");

    // Si la copia se hiciera correctamente sale el siguiente mensaje 
    printf("String copied\n");

//mensaje de afirmacion de la  cadena copiada

printf ("cadena copiada \n");    

    // Imprime la cadena copiada a q 

    printf("%s\n", q);

    return 0;  
 // Fin del programa
}

